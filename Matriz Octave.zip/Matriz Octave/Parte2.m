function c=Parte2(a,b)



c=[];

for x=1:length(a)

for i=1:length(b)
  
 var1=a(x)+b(i);
 
  if(mod(var1,3)==0)
  c=[c,a(x),b(i)];

 endif
 
 endfor
 

 endfor
 
 
  endfunction
  