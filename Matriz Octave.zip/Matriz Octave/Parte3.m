function c=Parte3(a,b)



c=[];

for x=1:length(a)

for i=1:length(b)
  
 
  if(a(x)<b(i))
  c=[c,a(x),b(i)];

 endif
 
 endfor
 

 endfor
 
 
  endfunction
  